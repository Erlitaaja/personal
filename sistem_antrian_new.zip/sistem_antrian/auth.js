// auth.js
const jwt = require('jsonwebtoken');
const secret = 'secret_key'; // Ganti dengan kunci rahasia yang lebih kuat

// Middleware untuk memeriksa token
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (token == null) return res.sendStatus(401);

    jwt.verify(token, secret, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
}

// Fungsi untuk membuat token
function generateAccessToken(username) {
    return jwt.sign({ username }, secret, { expiresIn: '1h' });
}

module.exports = { authenticateToken, generateAccessToken };
