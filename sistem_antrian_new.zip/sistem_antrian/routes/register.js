// routes/register.js
const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const db = require('../models/queue'); // Assuming this is your database connection file
const { generateAccessToken } = require('../auth');

// Endpoint for user registration
router.post('/register', (req, res) => {
    const { username, email, password } = req.body;
    console.log(req.body)
    if (!username || !email || !password) {
        return res.status(400).json({ message: 'Username, email, dan password diperlukan' });
    }

    // Hash the password
    bcrypt.hash(password, 10, (err, hashedPassword) => {
        if (err) {
            return res.status(500).json({ message: 'Terjadi kesalahan saat meng-hash password' });
        }

        // Query to insert new user
        const query = 'INSERT INTO users (username, email, password) VALUES (?, ?, ?)';
        db.query(query, [username, email, hashedPassword], (err, result) => {
            if (err) {
                console.error(err);
                return res.status(500).json({ message: err + ' Gagal mendaftarkan penggunaa' });
            }

            // Generate token upon successful registration
            const token = generateAccessToken(username);
            res.status(200).json({ message: 'Pengguna berhasil didaftarkan', token });
        });
    });
});

module.exports = router;
