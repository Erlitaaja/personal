// routes/login.js
const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const db = require('../models/queue');
const { generateAccessToken } = require('../auth');

// Endpoint untuk login
router.post('/login', (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ message: 'Username dan password diperlukan' });
    }

    // Query untuk mencari pengguna berdasarkan username
    db.query('SELECT * FROM users WHERE username = ?', [username], (err, results) => {

        if (err) return res.status(500).json({ message: 'Terjadi kesalahan' });
        if (results.length === 0) return res.status(401).json({ message: 'Username atau password salah1' });

        const user = results[0];
        bcrypt.compare(password, user.password, (err, isMatch) => {
            if (err) return res.status(500).json({ message: 'Terjadi kesalahan' });
            if (!isMatch) return res.status(401).json({ message: 'Username atau password salah2' });

            // Login berhasil, buat token
            const token = generateAccessToken(username);
            res.status(200).json({ token });
        });
    });
});

module.exports = router;
