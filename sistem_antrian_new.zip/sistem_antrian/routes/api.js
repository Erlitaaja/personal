const express = require('express');
const router = express.Router();
const db = require('../models/queue');
const multer = require('multer');
const path = require('path');

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'public/uploads/'); // Folder where files will be stored
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname)); // Generate unique filename
    }
});

const upload = multer({ storage: storage });

// Mendapatkan semua antrian
router.get('/queue', (req, res) => {
    db.query('SELECT * FROM queue', (err, results) => {
        if (err) throw err;
        res.json(results);
    });
});

// Menambahkan ke antrian
router.post('/queue', (req, res) => {
    const name = req.body.name;
    db.query('INSERT INTO queue (name) VALUES (?)', [name], (err, result) => {
        if (err) throw err;
        res.json({ id: result.insertId, name });
    });
});

router.post('/cover-letter/save', upload.single('coverLetter'), (req, res) => {

    const name = req.body.name;
    const subject = req.body.subject;
    const email = req.body.email;
    const address = req.body.address;
    const phone = req.body.phone;
    const message = req.body.message;
    const coverLetterFileName = req.file.filename;
    
    db.query(`
        INSERT INTO cover_letters (name, subject, email, address, phone, message, cover_letter)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    `, [name, subject, email, address, phone, message, coverLetterFileName], (err, result) => {
        if (err) throw err;
        // res.json({
        //     success: true,
        //     message: 'Berhasil menyimpan data!',
        //     data: {
        //         name, subject, email, address, phone, message, coverLetterFileName
        //     }
        // });

        req.flash('success', 'Form submitted successfully!');
        res.redirect('/administrasi.html?success=true');

    });
});

module.exports = router;
