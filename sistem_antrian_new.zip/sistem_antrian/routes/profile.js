const express = require('express');
const router = express.Router();
const db = require('../models/queue'); // Asumsi file koneksi database
const { authenticateToken } = require('../auth'); // Middleware untuk verifikasi token

// Endpoint untuk mendapatkan profil pengguna
router.get('/profile', authenticateToken, (req, res) => {
    const username = req.user.username; // Ambil username dari token yang terautentikasi

    // Query untuk mendapatkan data pengguna berdasarkan username
    const query = 'SELECT username, email FROM users WHERE username = ?';
    
    db.query(query, [username], (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ message: 'Terjadi kesalahan dalam mendapatkan data pengguna' });
        }

        if (results.length === 0) {
            return res.status(404).json({ message: 'Pengguna tidak ditemukan' });
        }

        // Mengembalikan data profil pengguna
        const user = results[0];
        res.status(200).json({
            message: 'Profil berhasil diambil',
            user: {
                username: user.username,
                email: user.email
            }
        });
    });
});

module.exports = router;
