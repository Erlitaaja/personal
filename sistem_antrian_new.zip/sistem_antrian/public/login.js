// login.js
document.getElementById('login-form').addEventListener('submit', function(event) {
    event.preventDefault();

    // Ambil nilai dari form
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;

    // Kirim permintaan login ke API
    fetch('user/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
    })
    .then(response => response.json())
    .then(data => {
        if (data.token) {
            // Simpan token di localStorage
            localStorage.setItem('loggedIn', 'true');
            localStorage.setItem('token', data.token);
            // Arahkan ke halaman utama
            window.location.href = 'index.html';
        } else {
            // Tampilkan pesan kesalahan
            document.getElementById('login-error').style.display = 'block';
        }
    })
    .catch(() => {
        document.getElementById('login-error').style.display = 'block';
    });
});
