document.getElementById('queue-form').addEventListener('submit', function (e) {
    e.preventDefault();
    const name = document.getElementById('name').value;

    fetch('/api/queue', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name })
    })
    .then(response => response.json())
    .then(data => {
        const listItem = document.createElement('li');
        listItem.textContent = `${data.id}: ${data.name}`;
        document.getElementById('queue-list').appendChild(listItem);
        document.getElementById('name').value = '';
    });
});

function loadQueue() {
    fetch('/api/queue')
        .then(response => response.json())
        .then(data => {
            const list = document.getElementById('queue-list');
            list.innerHTML = '';
            data.forEach(item => {
                const listItem = document.createElement('li');
                listItem.textContent = `${item.id}: ${item.name}`;
                list.appendChild(listItem);
            });
        });
}

loadQueue();
